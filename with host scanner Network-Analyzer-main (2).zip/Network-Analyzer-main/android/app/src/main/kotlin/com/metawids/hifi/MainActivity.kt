package com.metawids.hifi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
