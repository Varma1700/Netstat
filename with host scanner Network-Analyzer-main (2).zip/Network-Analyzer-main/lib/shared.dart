import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

const appColor = Colors.blue;
const appBgColor = Color(0xFF101111);
final appFont = GoogleFonts.ubuntuTextTheme();
final titleFont = GoogleFonts.montserrat();
