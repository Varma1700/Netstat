import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

showAppSnack(String msg) {
  try {
    Get.showSnackbar(GetSnackBar(
      message: msg,
    ));
  } catch (e) {
    debugPrint(e.toString());
  }
}
