class NetworkDetails {
  final String? wifiName;
  final String? wifiBSSID;
  final String? wifiIP;
  final String? wifiIPv6;
  final String? wifiSubmask;
  final String? wifiBroadcast;
  final String? wifiGatewayIP;

  NetworkDetails(
      {this.wifiName,
      this.wifiBSSID,
      this.wifiIP,
      this.wifiIPv6,
      this.wifiSubmask,
      this.wifiBroadcast,
      this.wifiGatewayIP});
}
