import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hifi/views/loaders.dart';
import 'package:network_info_plus/network_info_plus.dart';

import '../models/networ_details.dart';

class NetworkDetailsCard extends StatefulWidget {
  const NetworkDetailsCard({
    super.key,
  });

  @override
  State<NetworkDetailsCard> createState() => _NetworkDetailsCardState();
}

class _NetworkDetailsCardState extends State<NetworkDetailsCard> {
  final info = NetworkInfo();
  NetworkDetails? details;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    getWifiDetails();
  }

  getWifiDetails() async {
    try {
      setState(() => loading = true);
      details = NetworkDetails(
        wifiName: await info.getWifiName(),
        wifiBSSID: await info.getWifiBSSID(),
        wifiBroadcast: await info.getWifiBroadcast(),
        wifiGatewayIP: await info.getWifiGatewayIP(),
        wifiIP: await info.getWifiIP(),
        wifiIPv6: await info.getWifiIPv6(),
        wifiSubmask: await info.getWifiSubmask(),
      );
      setState(() => loading = false);
    } catch (e) {
      debugPrint(e.toString());
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: ShapeDecoration(
        color: Colors.white10,
        shape:
            ContinuousRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      child: details == null
          ? InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: () {
                getWifiDetails();
              },
              child: const SizedBox(child: rippleLoader))
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Network Name
                Row(
                  children: [
                    const Icon(
                      CupertinoIcons.wifi,
                      color: Colors.white70,
                      size: 20,
                    ),
                    const SizedBox(width: 4),
                    const Text(
                      "Network",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w300),
                    ),
                    const Spacer(),
                    loading
                        ? const SizedBox(
                            height: 18, width: 18, child: rippleLoader)
                        : GestureDetector(
                            onTap: () {
                              getWifiDetails();
                            },
                            child: const Icon(
                              CupertinoIcons.arrow_2_circlepath,
                              color: Colors.white70,
                              size: 18,
                            ),
                          ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  details?.wifiName ?? "Unknown",
                  style: const TextStyle(color: Colors.white, fontSize: 20),
                ),
                const SizedBox(height: 8),
                // IP Address
                const Row(
                  children: [
                    Icon(
                      Icons.location_searching_rounded,
                      color: Colors.white70,
                      size: 20,
                    ),
                    SizedBox(width: 4),
                    Text(
                      "IP Address",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w300),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      details?.wifiIPv6 ?? "",
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    Text(
                      details?.wifiIP ?? "",
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.wb_iridescent_rounded,
                              color: Colors.white70,
                              size: 20,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "BSSID",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300),
                            ),
                          ],
                        ),
                        Text(
                          details?.wifiBSSID ?? "",
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.broadcast_on_home_rounded,
                              color: Colors.white70,
                              size: 20,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "Broadcast",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300),
                            ),
                          ],
                        ),
                        Text(
                          details?.wifiBroadcast ?? "",
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.router_rounded,
                              color: Colors.white70,
                              size: 20,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "GatewayIP",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300),
                            ),
                          ],
                        ),
                        Text(
                          details?.wifiGatewayIP ?? "",
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.call_split_rounded,
                              color: Colors.white70,
                              size: 20,
                            ),
                            SizedBox(width: 4),
                            Text(
                              "Subnet mask",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300),
                            ),
                          ],
                        ),
                        Text(
                          details?.wifiSubmask ?? "",
                          style: const TextStyle(
                              color: Colors.white, fontSize: 16),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
    );
  }
}
