import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:hifi/shared.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:network_tools/network_tools.dart';
import 'package:get/get.dart';

class PortScannerWid extends StatefulWidget {
  const PortScannerWid({super.key});

  @override
  State<PortScannerWid> createState() => _PortScannerWidState();
}

class _PortScannerWidState extends State<PortScannerWid> {
  final info = NetworkInfo();
  RxDouble scanProgress = 0.0.obs;
  Set<ActiveHost> hostList = {};

  @override
  void initState() {
    super.initState();
    initScanner();
  }

  initScanner() async {
    await Future.delayed(const Duration(seconds: 3));
    portScanner();
  }

  Future portScanner() async {
    final String? address = await (info.getWifiIP());
    if (address == null) return;
    PortScanner.scanPortsForSingleDevice(address, startPort: 1, endPort: 1024,
        progressCallback: (progress) {
      debugPrint('Progress for port discovery : $progress');
      scanProgress.value = progress;
    }).listen((event) async {
      debugPrint('Found device: $event ${await event.deviceName}');
      setState(() {
        hostList.add(event);
      });
    }, onDone: () {
      debugPrint('Scan completed');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Obx(() => scanProgress.value == 100
                  ? const Text(
                      "Port Scanner",
                      style: TextStyle(color: Colors.white, fontSize: 22),
                    )
                  : Text(
                      scanProgress.value > 0
                          ? '${scanProgress.value.toStringAsFixed(2)}%'
                          : "Port Scanner",
                      style: const TextStyle(color: Colors.white, fontSize: 22),
                    )),
              InkWell(
                borderRadius: BorderRadius.circular(24),
                onTap: portScanner,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: appColor.withOpacity(.2),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: const Text(
                    "Scan Now",
                    style: TextStyle(color: appColor),
                  ),
                ),
              )
            ],
          ),
        ),
        const SizedBox(height: 8),
        ...List.generate(hostList.length, (index) {
          final host = hostList.toList()[index];
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Host Name",
                  style: TextStyle(color: Colors.white70),
                ),
                FutureBuilder<String?>(
                  future: host.hostName,
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      debugPrint(snapshot.error.toString());
                      return const Text(
                        "Not found",
                        style: TextStyle(color: Colors.white),
                      );
                    }
                    if (snapshot.hasData) {
                      return Text(
                        snapshot.data.toString(),
                        style: const TextStyle(color: Colors.white),
                      );
                    }
                    if (snapshot.data == null) {
                      return const Text(
                        "N.A",
                        style: TextStyle(color: Colors.white),
                      );
                    }
                    return const Text("Loading...",
                        style: TextStyle(color: Colors.white));
                  },
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Host Id",
                          style: TextStyle(color: Colors.white70),
                        ),
                        Text(
                          host.hostId,
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          "Address",
                          style: TextStyle(color: Colors.white70),
                        ),
                        Text(
                          host.address,
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Open Ports",
                          style: TextStyle(color: Colors.white70),
                        ),
                        Text(
                          '${host.openPorts.length}',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text(
                          "mDNS",
                          style: TextStyle(color: Colors.white70),
                        ),
                        FutureBuilder<MdnsInfo?>(
                          future: host.mdnsInfo,
                          builder: (context, snapshot) {
                            if (snapshot.hasError) {
                              debugPrint(snapshot.error.toString());
                              return const Text(
                                "Not found",
                                style: TextStyle(color: Colors.white),
                              );
                            }
                            if (snapshot.hasData) {
                              return Text(
                                snapshot.data.toString(),
                                style: const TextStyle(color: Colors.white),
                              );
                            }
                            if (snapshot.data == null) {
                              return const Text(
                                "N.A",
                                style: TextStyle(color: Colors.white),
                              );
                            }
                            return const Text("Loading...",
                                style: TextStyle(color: Colors.white));
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          );
        })
      ],
    );
  }
}
