import 'package:flutter/material.dart';
import 'package:hifi/shared.dart';
import 'package:hifi/views/loaders.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:network_tools/network_tools.dart';
import 'package:get/get.dart';

class HostScannerWid extends StatefulWidget {
  const HostScannerWid({super.key});

  @override
  State<HostScannerWid> createState() => _HostScannerWidState();
}

class _HostScannerWidState extends State<HostScannerWid> {
  final info = NetworkInfo();
  RxDouble scanProgress = 0.0.obs;
  Set<ActiveHost> hostList = {};
  List<ActiveHost> allHostList = <ActiveHost>[];
  bool loading = false;

  @override
  void initState() {
    super.initState();
    initScanner();
  }

  initScanner() async {
    await Future.delayed(const Duration(seconds: 3));
    hostScanner();
  }

  Future<void> hostScanner() async {
    try {
      setState(() => loading = true);
      final String? address = await (info.getWifiIP());
      if (address == null) return;
      final String subnet = address.substring(0, address.lastIndexOf('.'));
      final stream = HostScanner.getAllPingableDevices(subnet,
          firstHostId: 1, lastHostId: 254, progressCallback: (progress) {
        // print('Progress for host discovery : $progress');
        scanProgress.value = progress;
      });

      stream.listen((host) async {
        //Same host can be emitted multiple times
        //Use Set<ActiveHost> instead of List<ActiveHost>
        // debugPrint('Found device: $host ${await host.deviceName}');
        setState(() {
          hostList.add(host);
        });
      }, onDone: () {
        debugPrint('Scan completed');
      }); // Don't forget to cancel the stream when not in use.
      setState(() => loading = false);
    } catch (e) {
      debugPrint(e.toString());
      setState(() => loading = false);
    }

    // final Stream<ActiveHost> hostsDiscoveredInNetwork =
    //     HostScanner.getAllPingableDevices(
    //   subnetIsolate,
    //   firstHostId: firstSubnetIsolate,
    //   lastHostId: lastSubnetIsolate,
    // );

    // await for (final ActiveHost activeHostFound in hostsDiscoveredInNetwork) {
    //   activeHostFound.deviceName.then((value) {
    //     activeHostFound.mdnsInfo.then((value) {
    //       activeHostFound.hostName.then((value) {
    //        allHostList.add(activeHostFound);
    //       });
    //     });
    //   });
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Obx(() => scanProgress.value == 100
                  ? const Text(
                      "Host Scanner",
                      style: TextStyle(color: Colors.white, fontSize: 22),
                    )
                  : Text(
                      scanProgress.value > 0
                          ? '${scanProgress.value.toStringAsFixed(2)}%'
                          : "Preparing Scan...",
                      style: const TextStyle(color: Colors.white, fontSize: 22),
                    )),
              loading
                  ? spinnerLoader
                  : InkWell(
                      borderRadius: BorderRadius.circular(24),
                      onTap: hostScanner,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: appColor.withOpacity(.2),
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: const Text(
                          "Scan Now",
                          style: TextStyle(color: appColor),
                        ),
                      ),
                    )
            ],
          ),
        ),
        const SizedBox(height: 8),
        ...List.generate(hostList.length, (index) {
          final host = hostList.toList()[index];
          return InkWell(
            borderRadius: BorderRadius.circular(12),
            splashColor: appColor,
            onTap: () {},
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 4),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Device Name",
                    style: TextStyle(color: Colors.white70),
                  ),
                  FutureBuilder<String?>(
                    future: host.deviceName,
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        debugPrint(snapshot.error.toString());
                        return const Text(
                          "Not found",
                          style: TextStyle(color: Colors.white),
                        );
                      }
                      if (snapshot.hasData) {
                        return Text(
                          snapshot.data.toString(),
                          style: const TextStyle(color: Colors.white),
                        );
                      }
                      if (snapshot.data == null) {
                        return const Text(
                          "N.A",
                          style: TextStyle(color: Colors.white),
                        );
                      }
                      return const Text("Loading...",
                          style: TextStyle(color: Colors.white));
                    },
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Host Id",
                            style: TextStyle(color: Colors.white70),
                          ),
                          Text(
                            host.hostId,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            "Address",
                            style: TextStyle(color: Colors.white70),
                          ),
                          Text(
                            host.address,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Open Ports",
                            style: TextStyle(color: Colors.white70),
                          ),
                          Text(
                            '${host.openPorts.length}',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            "mDNS",
                            style: TextStyle(color: Colors.white70),
                          ),
                          FutureBuilder<MdnsInfo?>(
                            future: host.mdnsInfo,
                            builder: (context, snapshot) {
                              if (snapshot.hasError) {
                                debugPrint(snapshot.error.toString());
                                return const Text(
                                  "Not found",
                                  style: TextStyle(color: Colors.white),
                                );
                              }
                              if (snapshot.hasData) {
                                return Text(
                                  snapshot.data.toString(),
                                  style: const TextStyle(color: Colors.white),
                                );
                              }
                              if (snapshot.data == null) {
                                return const Text(
                                  "N.A",
                                  style: TextStyle(color: Colors.white),
                                );
                              }
                              return const Text("Loading...",
                                  style: TextStyle(color: Colors.white));
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        })
      ],
    );
  }
}
